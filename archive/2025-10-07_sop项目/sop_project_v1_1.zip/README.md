# 答题SOP工程（v1.1 · 解题思路图 + 学科出场矩阵）
创建时间：2025-10-03 03:24

本版本相对 v1.0 的关键变化：
- 将“路径图”统一更名为 **“解题思路图（WHY→HOW→RESULT）”**
- 引入 **学科出场矩阵**：
  - 数学/物理：**A + B + C 必出**
  - 化学：**A + B 必出**（不生成 C）
  - 生物：**仅 A**（禁止 B/C）
- 增加 **subject_module_policy.yaml** 与 Guard 规则，自动校验/重写
- A 方案增加 **对齐标识**：每步注明对应思路图 HOW(k)

使用建议：
1) 读 docs/SRS.md 与 docs/StyleGuide_Template_v1.1.md
2) 将 project/ 导入 ChatGPT“项目”，把 instructions/base_instructions.md 设为项目指令
3) 方案A：按 prompts/step1→step10 顺序运行；质量闸不通过→回溯重写
4) 方案B：One‑shot 时也必须遵守学科出场矩阵（见 subject_module_policy.yaml）
