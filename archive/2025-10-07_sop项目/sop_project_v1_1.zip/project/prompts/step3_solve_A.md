# step3_solve_A (学科矩阵：数学/物理/化学/生物均必须生成 A)
目标：按 MOJI 生成 A 方案（目的/操作/理由/检查），每步标注“对应 HOW(k)”。
输出：solutions.A。
